#include "subinputstream.h"

SubInputStream::SubInputStream(InputStream *input, long length) {
    this->input = input;
    left = length;
}
char
SubInputStream::read(const char*& start, size_t& nread, size_t max) {
    if (left == 0) {
        nread = 0;
        return -1;
    }
    // restrict the amount of data that can be read
    if (max > left || max == 0) max = left;
    status = input->read(start, nread, max);
    if (status) {
        printf("suberror %s\n", input->getError().c_str());
        return status;
    }
    left -= nread;
    return 0;
}
char
SubInputStream::mark(size_t readlimit) {
    markleft = left;
    return mark(readlimit);
}
char
SubInputStream::reset() {
    left = markleft;
    return reset();
}
char
SubInputStream::skipToEnd() {
    return skip(left);
}
