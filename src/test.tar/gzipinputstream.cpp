#include "gzipinputstream.h"
#include <zlib.h>

GZipInputStream::GZipInputStream(InputStream *input, ZipFormat format) {
    // initialize values that signal state
    status = 0;
    zstream = 0;
    finishedInflating = false;

    this->input = input;

    // initialize the buffer
    buffer.setSize(262144);

    // initialize the z_stream
    zstream = (z_stream_s*)malloc(sizeof(z_stream_s));
    zstream->zalloc = Z_NULL;
    zstream->zfree = Z_NULL;
    zstream->opaque = Z_NULL;
    zstream->avail_in = 0;
    zstream->next_in = Z_NULL;
    // initialize for reading gzip streams
    // for reading libz streams, you need inflateInit(zstream)
    int r;
    switch(format) {
    case ZLIBFORMAT:
        r = inflateInit(zstream);
        break;
    case GZIPFORMAT:
        r = inflateInit2(zstream, 15+16);
        break;
    case ZIPFORMAT:
        r = inflateInit2(zstream, -MAX_WBITS);
        break;
    }
    if (r != Z_OK) {
        error = "Error initializing GZipInputStream.";
        dealloc();
        status = -2;
        return;
    }
    // signal that we need to read into the buffer
    zstream->avail_out = 1;
}
GZipInputStream::~GZipInputStream() {
    dealloc();
}
void
GZipInputStream::dealloc() {
    if (zstream) {
        inflateEnd(zstream);
        free(zstream);
        zstream = 0;
    }
}
/**
 * Obtain small performance gain by reusing the object and its
 * allocated buffer and zstream.
 **/
void
GZipInputStream::restart(InputStream *input) {
    if (zstream == 0) {
        error = "Cannot restart GZipInputStream: state invalid.";
        status = -2;
        return;
    }
    this->input = input;
    char r = inflateReset(zstream);
    if (r != Z_OK) {
        status = -2;
        return;
    }
    status = 0;
    finishedInflating = false;
    // signal that we need to read into the buffer
    zstream->avail_out = 1;
}
char
GZipInputStream::read(const char*& start, size_t& nread, size_t max) {
    // if an error occured earlier, signal this
    if (status) return status;

    // if we cannot read and there's nothing in the buffer
    // (this can maybe be fixed by calling reset)
    if (finishedInflating && buffer.avail == 0) return -1;

    // check if there is still data in the buffer
    if (buffer.avail == 0) {
        decompressFromStream();
        if (status) return status;
    }

    // set the pointers to the available data
    buffer.read(start, nread, max);
    return 0;
}
void
GZipInputStream::readFromStream() {
    // read data from the input stream
    const char* inStart;
    size_t nread;
    status = input->read(inStart, nread);
    zstream->next_in = (Bytef*)inStart;
    zstream->avail_in = nread;
}
void
GZipInputStream::decompressFromStream() {
//    printf("decompress\n");
    // make sure there is data to decompress
    if (zstream->avail_out != 0) {
        readFromStream();
        if (status) {
            // no data was read
            return;
        }
    }
    // make sure we can write into the buffer
    int space = buffer.getWriteSpace();
    zstream->avail_out = space;
    zstream->next_out = (Bytef*)buffer.curPos;
    // decompress
    int r = inflate(zstream, Z_SYNC_FLUSH);
    // inform the buffer of the number of bytes that was read
    buffer.avail = space - zstream->avail_out;
    switch (r) {
    case Z_NEED_DICT:
        error = "Z_NEED_DICT while inflating stream.";
        status = -2;
        break;
    case Z_DATA_ERROR:
        error = "Z_DATA_ERROR while inflating stream.";
        status = -2;
        break;
    case Z_MEM_ERROR:
        error = "Z_MEM_ERROR while inflating stream.";
        status = -2;
        break;
    case Z_STREAM_END:
        // we are finished decompressing,
        // (but this stream is not yet finished)
        finishedInflating = true;
        break;
    }
}
char
GZipInputStream::mark(size_t readlimit) {
    buffer.mark(readlimit);
    return 0;
}
char
GZipInputStream::reset() {
    buffer.reset();
    return 0;
}
