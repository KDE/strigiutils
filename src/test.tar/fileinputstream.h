#ifndef FILEINPUTSTREAM_H
#define FILEINPUTSTREAM_H

#include "inputstream.h"
#include <cstdio>

class FileInputStream : public InputStream {
private:
    FILE *file;
    std::string filepath;
    InputStreamBuffer buffer;

    void readFromFile();
public:
    FileInputStream(const char *filepath);
    ~FileInputStream();
    char read(const char*& start, size_t& nread, size_t max = 0);
    char mark(size_t readlimit);
    char reset();
};

#endif

/**
 * if markPos is not set, we can best write data at the start of the buffer.
 * if markPos is set, we must continue writing where we left off (curPos+avail).
 * we need a function that returns pointers to the places where we want to write to
 **/
