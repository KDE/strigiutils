#include "tarinputstream.h"
#include "subinputstream.h"
#include <cstring>

TarInputStream::TarInputStream(InputStream *input) {
    this->input = input;
    output = 0;

    status = 0;
}

TarInputStream::~TarInputStream() {
}
SubInputStream*
TarInputStream::nextEntry() {
    readHeader();
    readHeader();
    readHeader();
    readHeader();
    return 0;
}
void
TarInputStream::readHeader() {
    char hb[512];
    char *bptr;
    int toread;
    const char *begin;
    size_t nread;

    // read the first 500 characters
    toread = 512;
    bptr = hb;
    while (toread) {
        char r = input->read(begin, nread, toread);
        if (r) {
            status = -2;
            error = "Error reading header: " + input->getError();
            return;
        }
        memcpy(bptr, begin, nread);
        bptr += nread;
        toread -= nread;
    }

    if (strlen(hb) > 100) {
        status = -2;
        error = "Error reading header: file name is too long.";
        return;
    }
    entryfilename.resize(0);
    entryfilename.append(hb);

    int r = sscanf(hb+124, "%u", &entrySize);
    if (r != 1) {
        status = -2;
        error = "Error reading header: " + input->getError();
        return;
    }
    input->skip(entrySize);
    size_t left = 512 - entrySize%512;
    if (left == 512) left = 0;
    input->skip(left);
    printf("file %s\n", entryfilename.c_str());
    printf("size %i\n", entrySize);
    printf("left %i\n", left);
    printf("type %c\n", hb[156]);
}
