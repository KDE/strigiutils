#ifndef SUBINPUTSTREAM_H
#define SUBINPUTSTREAM_H

#include "inputstream.h"

class SubInputStream : public InputStream {
private:
    ulong left;
    ulong markleft;
    InputStream *input;
public:
    SubInputStream(InputStream *input, long length);
    char read(const char*& start, size_t& nread, size_t max = 0);
    char mark(size_t readlimit);
    char reset();
    char skipToEnd();
};

#endif
