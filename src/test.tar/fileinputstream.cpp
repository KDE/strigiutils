#include "fileinputstream.h"

FileInputStream::FileInputStream(const char *filepath) {
    // initialize values that signal state
    status = 0;

    // try to open the file for reading
    file = fopen(filepath, "rb");
    this->filepath = filepath;
    if (file == NULL) {
        // handle error
        error = "Could not read file '";
        error += filepath;
        error += "'.";
        status = -2;
        return;
    }
    if (file) {
        // allocate memory in the buffer
        buffer.setSize(262144);
        //buffer.setSize(2621440); // big for testing
    }
}
FileInputStream::~FileInputStream() {
    if (file) {
        if (fclose(file)) {
            // handle error
            error = "Could not close file '" + filepath + "'.";
        }
    }
}
char
FileInputStream::read(const char*& start, size_t& nread, size_t max) {
    // if an error occured earlier, signal this
    if (status) return status;

    // if we cannot read and there's nothing in the buffer
    // (this can maybe be fixed by calling reset)
    if (file == NULL && buffer.avail == 0) return -1;

    // if buffer is empty, read from buffer
    if (buffer.avail == 0) {
        readFromFile();
        if (status) return status;
    }
    // set the pointers to the available data
    buffer.read(start, nread, max);
    return 0;
}
void
FileInputStream::readFromFile() {
    // prepare the buffer for writing
    size_t bytesRead = buffer.getWriteSpace();
    // read into the buffer
    bytesRead = fread(buffer.curPos, 1, bytesRead, file);
    buffer.avail = bytesRead;
    // check the file stream status
    if (ferror(file)) {
        error = "Could not read from file '" + filepath + "'.";
        fclose(file);
        file = NULL;
        status = -2;
    } else if (feof(file)) {
        fclose(file);
        file = NULL;
        if (bytesRead == 0) {
            status = -1;
        }
    }
}
char
FileInputStream::mark(size_t readlimit) {
    buffer.mark(readlimit);
    return 0;
}
char
FileInputStream::reset() {
    buffer.reset();
    return 0;
}
