#ifndef TARINPUTSTREAM_H
#define TARINPUTSTREAM_H

#include <string>

class InputStream;
class SubInputStream;

/**
 **/

class TarInputStream  {
private:
    char status;
    std::string error;
    InputStream *input;

    // information relating to the current entry
    std::string entryfilename;
    SubInputStream *output;
    size_t entrySize;

    void readFileName(size_t len);
    void readHeader();
    static size_t read2bytes(const unsigned char *b);
    static size_t read4bytes(const unsigned char *b);
public:
    TarInputStream(InputStream *input);
    ~TarInputStream();
    SubInputStream* nextEntry();
    std::string getEntryFileName() const { return entryfilename; }
    std::string getError() const { return error; }
};

#endif
