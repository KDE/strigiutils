#ifndef GZIPINPUTSTREAM_H
#define GZIPINPUTSTREAM_H

#include "inputstream.h"

struct z_stream_s;
class GZipInputStream : public InputStream {
private:
    bool finishedInflating;
    z_stream_s *zstream;
    InputStream *input;
    InputStreamBuffer buffer;

    void dealloc();
    void readFromStream();
    void decompressFromStream();
public:
    enum ZipFormat { ZLIBFORMAT, GZIPFORMAT, ZIPFORMAT};
    GZipInputStream(InputStream *input, ZipFormat format=GZIPFORMAT);
    ~GZipInputStream();
    void restart(InputStream *input);
    char read(const char*& start, size_t& nread, size_t max = 0);
    char mark(size_t readlimit);
    char reset();
};

#endif
