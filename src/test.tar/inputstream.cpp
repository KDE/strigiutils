#include "inputstream.h"

char
InputStream::skip(size_t ntoskip) {
    const char *begin;
    size_t nread;
    while (ntoskip) {
        char r = read(begin, nread, ntoskip);
        if (r) return r;
        ntoskip -= nread;
    }
    return 0;
}
InputStreamBuffer::InputStreamBuffer() {
    markPos = curPos = start = NULL;
    size = avail = 0;
}
InputStreamBuffer::~InputStreamBuffer() {
    free(start);
}
void
InputStreamBuffer::setSize(size_t size) {
    // store pointer information
    size_t offset = curPos - start;
    // allocate memory in the buffer
    start = (char*)realloc(start, size);
    this->size = size;
    // restore pointer information
    curPos = start + offset;
}
void
InputStreamBuffer::mark(size_t readlimit) {
    // if we have enough room, dont change anything
    size_t offset = curPos - start;
    if (size - offset >= readlimit) {
        markPos = curPos;
        return;
    }

    // move memory to the start of the buffer
    if (curPos != start) {
        memmove(start, curPos, avail);
        curPos = start;
    }

    // if we have enough room now, finish
    if (size >= readlimit) {
        markPos = curPos;
        return;
    }

    // last resort: increase buffer size
    setSize(readlimit);
    markPos = curPos;
}
void
InputStreamBuffer::reset() {
    if (markPos != NULL) {
        avail += curPos - markPos;
        curPos = markPos;
    }
}
size_t
InputStreamBuffer::getWriteSpace() {
    // advance the buffer to where the last write left off
    curPos += avail;
    // calculate how much space is left at the end of the buffer
    size_t writeSpace = size - (curPos - start);
    if (markPos == NULL || writeSpace <= 0) {
        // if there is no mark or the buffer is full,
        // we set the next write to the start of the buffer
        markPos = NULL;
        writeSpace = size;
        curPos = start;
    }
    return writeSpace;
}
void
InputStreamBuffer::read(const char*& start, size_t& nread, size_t max) {
    start = curPos;
    if (max <= 0 || max > avail) {
        max = avail;
    }
    curPos += max;
    avail -= max;
    nread = max;
}
