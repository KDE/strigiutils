#ifndef INPUTSTREAM_H
#define INPUTSTREAM_H

#include <string>

class InputStream {
protected:
    std::string error;
    char status; // 0: all ok, -1: EOF, -2 error
public:
    virtual ~InputStream() {}
    const std::string& getError() const {
        return error;
    }
    /**
     * Reads input data and points the input pointers to the read
     * data.
     * If the end of stream is reached, -1 is returned.
     * If an error occured, -2 is returned.
     * No more than @param max data wil be read. If @param max == 0, there's no limit.
     **/
    virtual char read(const char*& start, size_t& read, size_t max = 0) = 0;
    /**
     * Skip @param ntoskip bytes. Unless an error occurs or the end of file is
     * encountered, this amount of bytes is skipped.
     * If the end of stream is reached, -1 is returned.
     * If an error occured, -2 is returned.
     **/
    virtual char skip(size_t ntoskip);
    virtual char mark(size_t readlimit) = 0;
    virtual char reset() = 0;
};

class InputStreamBuffer {
private:
public:
    char *start;
    size_t size;
    char *curPos;
    size_t avail;
    char *markPos;

    InputStreamBuffer();
    ~InputStreamBuffer();
    void setSize(size_t size);
    void mark(size_t readlimit);
    void reset();
    void read(const char*& start, size_t& end, size_t max);

    /**
     * This function prepares the buffer for a new write.
     * Any data not read since the last write is lost.
     * returns the number of available places.
     **/
    size_t getWriteSpace();
};

#endif
